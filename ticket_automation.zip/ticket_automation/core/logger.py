"""
logger.py
Configura logging robusto: saída no console + arquivo rotativo em logs/.
Isso garante rastreabilidade de cada execução (essencial para automação
usada em ambiente de trabalho real).
"""
import logging
import os
from logging.handlers import RotatingFileHandler


def setup_logger(log_folder: str, level=logging.INFO):
    os.makedirs(log_folder, exist_ok=True)
    logger = logging.getLogger("ticket_automation")
    logger.setLevel(level)
    logger.handlers.clear()

    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s", "%Y-%m-%d %H:%M:%S")

    console = logging.StreamHandler()
    console.setFormatter(fmt)
    logger.addHandler(console)

    file_handler = RotatingFileHandler(
        os.path.join(log_folder, "automacao.log"),
        maxBytes=1_000_000,
        backupCount=5,
        encoding="utf-8",
    )
    file_handler.setFormatter(fmt)
    logger.addHandler(file_handler)

    return logger
