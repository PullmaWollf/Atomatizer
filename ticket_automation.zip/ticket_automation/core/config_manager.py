"""
config_manager.py
Gerencia as configurações globais (settings.json) e o CRUD completo de
macros salvos em disco (pasta macros/, um arquivo JSON por macro),
incluindo duplicação, exportação e importação (para reaproveitar ou
compartilhar automações entre máquinas/colegas).
"""
import json
import os
import shutil
import logging

logger = logging.getLogger("ticket_automation")

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SETTINGS_PATH = os.path.join(BASE_DIR, "settings.json")
MACROS_DIR = os.path.join(BASE_DIR, "macros")
REPORTS_DIR = os.path.join(BASE_DIR, "reports")

DEFAULT_SETTINGS = {
    "browser": {
        "type": "chrome",
        "headless": True,
        "window_size": [1366, 768],
        "profile_path": None,
        "implicit_wait": 10,
    },
    "data_folder": os.path.join(BASE_DIR, "data"),
    "log_folder": os.path.join(BASE_DIR, "logs"),
    "reports_folder": REPORTS_DIR,
    "screenshot_folder": os.path.join(BASE_DIR, "logs", "screenshots"),
    "default_retries": 2,
    "screenshot_on_error": True,
}


def load_settings() -> dict:
    if not os.path.exists(SETTINGS_PATH):
        save_settings(DEFAULT_SETTINGS)
        return json.loads(json.dumps(DEFAULT_SETTINGS))
    with open(SETTINGS_PATH, encoding="utf-8") as f:
        settings = json.load(f)
    # garante que configs novas existam mesmo em settings.json antigos
    changed = False
    for key, value in DEFAULT_SETTINGS.items():
        if key not in settings:
            settings[key] = value
            changed = True
    if changed:
        save_settings(settings)
    return settings


def save_settings(settings: dict):
    with open(SETTINGS_PATH, "w", encoding="utf-8") as f:
        json.dump(settings, f, indent=2, ensure_ascii=False)
    logger.info("Configurações salvas.")


# ---------------------------------------------------------------------------
# CRUD de macros
# ---------------------------------------------------------------------------
def list_macros():
    os.makedirs(MACROS_DIR, exist_ok=True)
    return sorted(f[:-5] for f in os.listdir(MACROS_DIR) if f.endswith(".json"))


def macro_path(name: str) -> str:
    return os.path.join(MACROS_DIR, f"{name}.json")


def macro_exists(name: str) -> bool:
    return os.path.exists(macro_path(name))


def load_macro(name: str) -> dict:
    path = macro_path(name)
    if not os.path.exists(path):
        raise FileNotFoundError(f"Macro '{name}' não existe.")
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def save_macro(name: str, macro_dict: dict):
    os.makedirs(MACROS_DIR, exist_ok=True)
    with open(macro_path(name), "w", encoding="utf-8") as f:
        json.dump(macro_dict, f, indent=2, ensure_ascii=False)
    logger.info(f"Macro '{name}' salvo em {macro_path(name)}")


def delete_macro(name: str):
    path = macro_path(name)
    if os.path.exists(path):
        os.remove(path)
        logger.info(f"Macro '{name}' removido.")


def rename_macro(old_name: str, new_name: str):
    if not macro_exists(old_name):
        raise FileNotFoundError(f"Macro '{old_name}' não existe.")
    if macro_exists(new_name):
        raise FileExistsError(f"Já existe um macro chamado '{new_name}'.")
    d = load_macro(old_name)
    d["name"] = new_name
    save_macro(new_name, d)
    delete_macro(old_name)
    logger.info(f"Macro renomeado de '{old_name}' para '{new_name}'.")


def duplicate_macro(name: str, new_name: str):
    """Clona um macro existente com um novo nome — essencial no uso white
    label: parte de um macro que já funciona e ajusta só o necessário para
    a nova demanda repetitiva."""
    if not macro_exists(name):
        raise FileNotFoundError(f"Macro '{name}' não existe.")
    if macro_exists(new_name):
        raise FileExistsError(f"Já existe um macro chamado '{new_name}'.")
    d = load_macro(name)
    d["name"] = new_name
    save_macro(new_name, d)
    logger.info(f"Macro '{name}' duplicado como '{new_name}'.")


def export_macro(name: str, destination_path: str):
    """Copia o JSON do macro para um caminho externo (backup / compartilhar
    com outro colega ou outra máquina)."""
    src = macro_path(name)
    if not os.path.exists(src):
        raise FileNotFoundError(f"Macro '{name}' não existe.")
    os.makedirs(os.path.dirname(destination_path) or ".", exist_ok=True)
    shutil.copyfile(src, destination_path)
    logger.info(f"Macro '{name}' exportado para {destination_path}")
    return destination_path


def import_macro(source_path: str, new_name: str = None):
    """Importa um arquivo .json de macro de qualquer caminho do sistema
    operacional para dentro da pasta macros/ do projeto."""
    if not os.path.exists(source_path):
        raise FileNotFoundError(f"Arquivo não encontrado: {source_path}")
    with open(source_path, encoding="utf-8") as f:
        d = json.load(f)
    name = new_name or d.get("name") or os.path.splitext(os.path.basename(source_path))[0]
    if macro_exists(name):
        raise FileExistsError(f"Já existe um macro chamado '{name}'. Escolha outro nome.")
    d["name"] = name
    save_macro(name, d)
    logger.info(f"Macro importado de {source_path} como '{name}'.")
    return name
