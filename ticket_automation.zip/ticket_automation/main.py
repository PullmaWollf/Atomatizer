"""
main.py
=========================================================
AUTOMAÇÃO WEB - Menu Interativo (White Label)
=========================================================
Ferramenta genérica de automação de navegador via Selenium. O mesmo
código serve para QUALQUER processo repetitivo em qualquer sistema web
(Microvix, Linx, portais internos, sistemas de terceiros etc). O que
muda entre uma automação e outra é apenas o "macro" (arquivo de
configuração), criado interativamente por este menu.

Menu principal:
  1. Executar Macro
  2. Marcar Coordenadas      -> cria/edita/reordena os passos de um macro
  3. Limpar Coordenadas      -> remove passos de um macro existente
  4. Gerenciar Macros        -> duplicar / exportar / importar / renomear
  5. Configurações
  6. Sair
"""
import csv
import os
import sys
import threading
import time
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core import config_manager as cfg
from core.logger import setup_logger
from core.locator import LocatorType
from core.macro import (
    Macro,
    MacroStep,
    MacroExecutor,
    VALID_ACTIONS,
    ACTION_LABELS,
    NO_LOCATOR_ACTIONS,
    VALUE_ACTIONS,
    _KEY_ALIASES,
)
from core.driver_manager import build_driver
from core.data_source import DataSource

SETTINGS = cfg.load_settings()
logger = setup_logger(SETTINGS["log_folder"])

RUNNING_THREADS = {}   # nome_macro -> threading.Thread


# ---------------------------------------------------------------------------
# Helpers de input
# ---------------------------------------------------------------------------
def clear():
    os.system("cls" if os.name == "nt" else "clear")


def pause():
    input("\nPressione ENTER para continuar...")


def ask_choice(prompt, options, allow_cancel=True):
    while True:
        print(f"\n{prompt}")
        for i, opt in enumerate(options, 1):
            print(f"  {i}. {opt}")
        if allow_cancel:
            print("  0. Cancelar")
        raw = input("Escolha: ").strip()
        if allow_cancel and raw == "0":
            return None
        if raw.isdigit() and 1 <= int(raw) <= len(options):
            return int(raw) - 1
        print("Opção inválida.")


def ask_text(prompt, default=None, allow_empty=False):
    suffix = f" [{default}]" if default is not None else ""
    while True:
        raw = input(f"{prompt}{suffix}: ").strip()
        if not raw and default is not None:
            return default
        if not raw and allow_empty:
            return ""
        if raw:
            return raw
        print("Valor obrigatório.")


def ask_float(prompt, default=0.0):
    raw = input(f"{prompt} [{default}]: ").strip()
    if not raw:
        return default
    try:
        return float(raw.replace(",", "."))
    except ValueError:
        print("Valor inválido, usando padrão.")
        return default


def ask_yes_no(prompt, default=True):
    d = "S" if default else "N"
    raw = input(f"{prompt} (s/n) [{d}]: ").strip().lower()
    if not raw:
        return default
    return raw.startswith("s")


def executor_kwargs():
    return dict(
        default_retries=int(SETTINGS.get("default_retries", 2)),
        screenshot_on_error=SETTINGS.get("screenshot_on_error", True),
        screenshot_dir=SETTINGS.get("screenshot_folder", "logs/screenshots"),
    )


# ---------------------------------------------------------------------------
# Relatório de execução em lote
# ---------------------------------------------------------------------------
def _gravar_relatorio(macro_name, resultados):
    os.makedirs(SETTINGS["reports_folder"], exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = os.path.join(SETTINGS["reports_folder"], f"{macro_name}_{ts}.csv")
    campos = ["linha", "status", "erro", "variaveis_capturadas"]
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=campos)
        writer.writeheader()
        for r in resultados:
            writer.writerow(r)
    return path


# ---------------------------------------------------------------------------
# 1. Executar Macro
# ---------------------------------------------------------------------------
def _executar_macro_worker(macro: Macro, data_rows, headless_override=None):
    driver = None
    try:
        browser_cfg = dict(SETTINGS["browser"])
        if macro.browser_override:
            browser_cfg.update(macro.browser_override)
        if headless_override is not None:
            browser_cfg["headless"] = headless_override

        driver = build_driver(browser_cfg)
        data_source = DataSource(SETTINGS["data_folder"])
        executor = MacroExecutor(driver, data_source, **executor_kwargs())

        if data_rows:
            resultados = []
            for i, row in enumerate(data_rows, 1):
                logger.info(f"[{macro.name}] Registro {i}/{len(data_rows)}: {row}")
                try:
                    variaveis = executor.run(macro, data_row=row)
                    resultados.append(
                        {"linha": i, "status": "OK", "erro": "", "variaveis_capturadas": variaveis}
                    )
                except Exception as e:
                    logger.error(f"[{macro.name}] Registro {i} FALHOU: {e}")
                    resultados.append(
                        {"linha": i, "status": "ERRO", "erro": str(e), "variaveis_capturadas": ""}
                    )
            path = _gravar_relatorio(macro.name, resultados)
            ok = sum(1 for r in resultados if r["status"] == "OK")
            logger.info(
                f"[{macro.name}] Lote concluído: {ok}/{len(resultados)} OK. "
                f"Relatório: {path}"
            )
        else:
            executor.run(macro)
            logger.info(f"[{macro.name}] Execução finalizada com sucesso.")

    except Exception as e:
        logger.error(f"[{macro.name}] ERRO durante a execução: {e}")
    finally:
        if driver:
            driver.quit()
        RUNNING_THREADS.pop(macro.name, None)


def menu_executar_macro():
    clear()
    macros = cfg.list_macros()
    if not macros:
        print("Nenhum macro cadastrado ainda. Use a opção 'Marcar Coordenadas' primeiro.")
        pause()
        return

    idx = ask_choice("=== EXECUTAR MACRO ===\nEscolha o macro:", macros)
    if idx is None:
        return
    name = macros[idx]
    macro = Macro.from_dict(cfg.load_macro(name))

    if not macro.steps:
        print("Este macro não tem passos configurados.")
        pause()
        return

    usar_dados = ask_yes_no(
        "\nEsta execução deve repetir o macro para VÁRIOS registros de um arquivo de dados?",
        default=False,
    )
    data_rows = None
    if usar_dados:
        data_source = DataSource(SETTINGS["data_folder"])
        arquivos = data_source.list_files()
        if not arquivos:
            print(f"Nenhum arquivo encontrado em '{SETTINGS['data_folder']}'.")
            pause()
            return
        idx2 = ask_choice("Escolha o arquivo de dados:", arquivos)
        if idx2 is None:
            return
        data_rows = data_source.load_rows(arquivos[idx2])
        print(f"{len(data_rows)} registro(s) carregado(s).")

    ver_execucao = ask_yes_no(
        "\nQuer VER o navegador rodando agora (janela visível, só para esta execução)?",
        default=False,
    )
    headless_override = False if ver_execucao else None

    modo_daemon = ask_yes_no(
        "\nExecutar em segundo plano (thread daemon), liberando o menu imediatamente?",
        default=not ver_execucao,
    )

    if macro.name in RUNNING_THREADS:
        print(f"O macro '{macro.name}' já está em execução.")
        pause()
        return

    if modo_daemon:
        t = threading.Thread(
            target=_executar_macro_worker,
            args=(macro, data_rows, headless_override),
            daemon=True,
        )
        RUNNING_THREADS[macro.name] = t
        t.start()
        print(
            f"\nMacro '{macro.name}' iniciado em segundo plano. "
            f"Acompanhe em logs/automacao.log."
        )
    else:
        print("\nExecutando (modo bloqueante)...")
        _executar_macro_worker(macro, data_rows, headless_override)
    pause()


# ---------------------------------------------------------------------------
# 2. Marcar Coordenadas (criar/editar/reordenar macro)
# ---------------------------------------------------------------------------
def _escolher_ou_criar_macro():
    macros = cfg.list_macros()
    opcoes = ["Criar novo macro"] + macros
    idx = ask_choice("Escolha um macro para editar ou crie um novo:", opcoes)
    if idx is None:
        return None
    if idx == 0:
        nome = ask_text("Nome do novo macro (sem espaços/acentos)")
        url = ask_text("URL inicial que o navegador deve abrir (ex: https://sistema.com/login)")
        macro = Macro(name=nome, start_url=url)
        cfg.save_macro(nome, macro.to_dict())
        return macro
    nome = macros[idx - 1]
    return Macro.from_dict(cfg.load_macro(nome))


def _capturar_dados_passo(existing: MacroStep = None):
    """Fluxo de perguntas compartilhado entre 'adicionar passo' e 'editar
    passo'. Retorna um dict com os campos coletados (sem o 'id')."""
    acoes = list(VALID_ACTIONS)
    default_idx = acoes.index(existing.action) + 1 if existing else None
    print(
        f"\n(Passo atual: {ACTION_LABELS.get(existing.action)})" if existing else ""
    )
    idx_acao = ask_choice(
        "Ação a executar:", [ACTION_LABELS.get(a, a) for a in acoes]
    )
    if idx_acao is None:
        return None
    action = acoes[idx_acao]

    locator_type = None
    locator_value = None
    if action not in NO_LOCATOR_ACTIONS:
        precisa_locator = True
        if action == "press_key":
            precisa_locator = ask_yes_no(
                "Enviar a tecla para um elemento específico? "
                "(não = envia para o elemento em foco no momento)",
                default=bool(existing and existing.locator_type),
            )
        if precisa_locator:
            tipos = [t.value for t in LocatorType.menu()]
            idx_tipo = ask_choice("Tipo de localizador do elemento HTML:", tipos)
            if idx_tipo is None:
                return None
            locator_type = tipos[idx_tipo]
            if locator_type == "XPATH":
                exemplo = "//button[@id='salvar']"
            elif locator_type == "CSS_SELECTOR":
                exemplo = "#salvar, .btn-primary"
            else:
                exemplo = "salvar"
            locator_value = ask_text(
                f"Valor do localizador (ex: {exemplo})",
                default=existing.locator_value if existing else None,
            )

    value_source = None
    value = None
    variable_name = None
    select_by = None

    if action in VALUE_ACTIONS:
        origem_opcoes = [
            "Texto fixo (digitado agora)",
            "Coluna de um arquivo de dados (data/)",
            "Variável capturada por um passo 'extract'/'execute_js' anterior",
        ]
        origem = ask_choice("De onde vem o valor?", origem_opcoes)
        if origem is None:
            return None
        value_source = {0: "fixed", 1: "data", 2: "captured"}[origem]
        if origem == 0:
            if action == "upload_file":
                value = ask_text(
                    "Nome do arquivo a enviar (deve estar dentro da pasta de dados). "
                    "Dica: pode usar {{variavel}} para montar caminhos dinâmicos"
                )
            else:
                value = ask_text(
                    "Texto/valor fixo. Dica: pode usar {{variavel}} para incluir "
                    "valores capturados anteriormente"
                )
        elif origem == 1:
            value = ask_text("Nome da COLUNA no arquivo de dados (cabeçalho do CSV/JSON)")
        else:
            value = ask_text("Nome da variável já capturada neste macro")

        if action == "select":
            idx_sb = ask_choice(
                "Selecionar a opção do <select> por:",
                ["Texto visível", "Atributo value", "Índice"],
            )
            select_by = {0: "text", 1: "value", 2: "index"}.get(idx_sb, "text")

    elif action == "wait":
        value = str(ask_float("Quantos segundos aguardar?", 1.0))

    elif action == "wait_manual":
        value = ask_text(
            "Mensagem a exibir para o operador (ex: 'Resolva o CAPTCHA e pressione ENTER')",
            default="Ação manual necessária.",
        )

    elif action == "press_key":
        nomes = list(_KEY_ALIASES.keys())
        idx_key = ask_choice("Qual tecla enviar?", nomes)
        if idx_key is None:
            return None
        value = nomes[idx_key]

    elif action == "extract":
        quer_atributo = ask_yes_no(
            "Extrair um ATRIBUTO específico do elemento? (não = extrai o texto visível)",
            default=False,
        )
        value = ask_text("Nome do atributo (ex: value, href, data-id)") if quer_atributo else None
        variable_name = ask_text("Nome da variável para guardar este valor capturado")

    elif action == "execute_js":
        value = ask_text(
            "Código JavaScript a executar (use 'return ...' se quiser capturar um valor)"
        )
        quer_var = ask_yes_no("Guardar o retorno deste script em uma variável?", default=False)
        variable_name = ask_text("Nome da variável") if quer_var else None

    elif action == "screenshot":
        value = ask_text(
            "Nome do arquivo do print (opcional, ENTER para gerar automático)",
            allow_empty=True,
        ) or None

    elif action == "switch_to_window":
        value = ask_text("Índice da janela/aba (0 = primeira aberta, 1 = segunda...)", default="0")

    optional = False
    if action not in NO_LOCATOR_ACTIONS:
        optional = ask_yes_no(
            "Este passo é OPCIONAL? (se o elemento não existir, pula sem falhar o macro)",
            default=existing.optional if existing else False,
        )

    wait_before = ask_float("Aguardar quantos segundos ANTES deste passo?", existing.wait_before if existing else 0)
    wait_after = ask_float("Aguardar quantos segundos DEPOIS deste passo?", existing.wait_after if existing else 0)
    timeout = ask_float(
        "Timeout (segundos) para localizar o elemento?", existing.timeout if existing else 10
    )

    return dict(
        action=action,
        locator_type=locator_type,
        locator_value=locator_value,
        value_source=value_source,
        value=value,
        variable_name=variable_name,
        select_by=select_by,
        optional=optional,
        wait_before=wait_before,
        wait_after=wait_after,
        timeout=timeout,
    )


def _adicionar_passo(macro: Macro):
    print(f"\n--- Novo passo para o macro '{macro.name}' ---")
    dados = _capturar_dados_passo()
    if dados is None:
        return
    step = MacroStep(id=macro.next_id(), **dados)
    macro.steps.append(step)
    cfg.save_macro(macro.name, macro.to_dict())
    print(f"Passo #{step.id} adicionado e salvo.")


def _editar_passo(macro: Macro):
    if not macro.steps:
        print("Nenhum passo para editar.")
        return
    num = ask_text("Número do passo a editar")
    if not num.isdigit():
        return
    step_id = int(num)
    step = next((s for s in macro.steps if s.id == step_id), None)
    if not step:
        print("Passo não encontrado.")
        return
    print(f"\n--- Editando passo #{step_id} ---")
    dados = _capturar_dados_passo(existing=step)
    if dados is None:
        return
    for k, v in dados.items():
        setattr(step, k, v)
    cfg.save_macro(macro.name, macro.to_dict())
    print(f"Passo #{step_id} atualizado.")


def _reordenar_passos(macro: Macro):
    if len(macro.steps) < 2:
        print("É preciso ao menos 2 passos para reordenar.")
        return
    num = ask_text("Número do passo a mover")
    if not num.isdigit():
        return
    direcao = ask_choice("Mover para:", ["Cima", "Baixo"])
    if direcao is None:
        return
    ok = macro.move_step(int(num), -1 if direcao == 0 else 1)
    if ok:
        cfg.save_macro(macro.name, macro.to_dict())
        print("Passo reordenado.")
    else:
        print("Não foi possível mover (já está na ponta ou passo inexistente).")


def menu_marcar_coordenadas():
    clear()
    print("=== MARCAR COORDENADAS (elementos do HTML) ===")
    macro = _escolher_ou_criar_macro()
    if macro is None:
        return

    while True:
        clear()
        print(f"Macro atual: {macro.name}  |  URL inicial: {macro.start_url}")
        print(f"Passos configurados: {len(macro.steps)}")
        for s in macro.steps:
            extra = " [OPCIONAL]" if s.optional else ""
            print(f"  [{s.id}] {ACTION_LABELS.get(s.action, s.action)} "
                  f"-> {s.locator_type or '-'}='{s.locator_value or '-'}'{extra}")

        idx = ask_choice(
            "\nO que deseja fazer?",
            [
                "Adicionar novo passo (marcar novo elemento)",
                "Editar um passo existente",
                "Reordenar passos (mover para cima/baixo)",
                "Alterar URL inicial do macro",
                "Voltar ao menu principal",
            ],
        )
        if idx is None or idx == 4:
            return
        if idx == 0:
            _adicionar_passo(macro)
            pause()
        elif idx == 1:
            _editar_passo(macro)
            pause()
        elif idx == 2:
            _reordenar_passos(macro)
            pause()
        elif idx == 3:
            macro.start_url = ask_text("Nova URL inicial", default=macro.start_url)
            cfg.save_macro(macro.name, macro.to_dict())


# ---------------------------------------------------------------------------
# 3. Limpar Coordenadas
# ---------------------------------------------------------------------------
def menu_limpar_coordenadas():
    clear()
    macros = cfg.list_macros()
    if not macros:
        print("Nenhum macro cadastrado.")
        pause()
        return

    idx = ask_choice("=== LIMPAR COORDENADAS ===\nEscolha o macro:", macros)
    if idx is None:
        return
    name = macros[idx]
    macro = Macro.from_dict(cfg.load_macro(name))

    if not macro.steps:
        print("Este macro já não tem passos.")
        pause()
        return

    print(f"\nPassos de '{name}':")
    for s in macro.steps:
        print(f"  [{s.id}] {ACTION_LABELS.get(s.action, s.action)} -> {s.locator_type}='{s.locator_value}'")

    idx2 = ask_choice(
        "\nO que deseja limpar?",
        ["Remover um passo específico (pelo número)", "Limpar TODOS os passos", "Excluir o macro inteiro"],
    )
    if idx2 is None:
        return

    if idx2 == 0:
        num = ask_text("Número do passo a remover")
        if num.isdigit():
            macro.steps = [s for s in macro.steps if s.id != int(num)]
            cfg.save_macro(name, macro.to_dict())
            print("Passo removido.")
    elif idx2 == 1:
        if ask_yes_no(f"Confirma limpar TODOS os passos de '{name}'?", default=False):
            macro.steps = []
            cfg.save_macro(name, macro.to_dict())
            print("Todos os passos foram removidos.")
    elif idx2 == 2:
        if ask_yes_no(f"Confirma EXCLUIR o macro '{name}' inteiro?", default=False):
            cfg.delete_macro(name)
            print("Macro excluído.")
    pause()


# ---------------------------------------------------------------------------
# 4. Gerenciar Macros (duplicar / exportar / importar / renomear)
# ---------------------------------------------------------------------------
def menu_gerenciar_macros():
    clear()
    macros = cfg.list_macros()
    idx = ask_choice(
        "=== GERENCIAR MACROS ===",
        [
            "Duplicar um macro existente (reaproveitar para nova demanda)",
            "Renomear um macro",
            "Exportar um macro (.json) para outro caminho",
            "Importar um macro (.json) de outro caminho",
        ],
    )
    if idx is None:
        return

    if idx == 0:
        if not macros:
            print("Nenhum macro para duplicar.")
            pause()
            return
        i = ask_choice("Escolha o macro a duplicar:", macros)
        if i is None:
            return
        novo_nome = ask_text("Nome do novo macro")
        try:
            cfg.duplicate_macro(macros[i], novo_nome)
            print(f"Macro duplicado como '{novo_nome}'.")
        except Exception as e:
            print(f"Erro: {e}")

    elif idx == 1:
        if not macros:
            print("Nenhum macro para renomear.")
            pause()
            return
        i = ask_choice("Escolha o macro a renomear:", macros)
        if i is None:
            return
        novo_nome = ask_text("Novo nome")
        try:
            cfg.rename_macro(macros[i], novo_nome)
            print("Macro renomeado.")
        except Exception as e:
            print(f"Erro: {e}")

    elif idx == 2:
        if not macros:
            print("Nenhum macro para exportar.")
            pause()
            return
        i = ask_choice("Escolha o macro a exportar:", macros)
        if i is None:
            return
        destino = ask_text(
            "Caminho completo do arquivo de destino (ex: /mnt/user-data/outputs/meu_macro.json)"
        )
        try:
            path = cfg.export_macro(macros[i], destino)
            print(f"Exportado para: {path}")
        except Exception as e:
            print(f"Erro: {e}")

    elif idx == 3:
        origem = ask_text("Caminho completo do arquivo .json a importar")
        try:
            nome = cfg.import_macro(origem)
            print(f"Macro importado como '{nome}'.")
        except Exception as e:
            print(f"Erro: {e}")

    pause()


# ---------------------------------------------------------------------------
# 5. Configurações
# ---------------------------------------------------------------------------
def menu_configuracoes():
    global SETTINGS
    while True:
        clear()
        b = SETTINGS["browser"]
        print("=== CONFIGURAÇÕES ===")
        print(f"1. Navegador: {b['type']}")
        print(f"2. Headless (sem janela visível): {b['headless']}")
        print(f"3. Tamanho da janela: {b['window_size']}")
        print(f"4. Profile do navegador (login salvo): {b['profile_path']}")
        print(f"5. Espera implícita (s): {b['implicit_wait']}")
        print(f"6. Pasta de dados: {SETTINGS['data_folder']}")
        print(f"7. Pasta de logs: {SETTINGS['log_folder']}")
        print(f"8. Pasta de relatórios: {SETTINGS['reports_folder']}")
        print(f"9. Tentativas em falha transitória (retry): {SETTINGS['default_retries']}")
        print(f"10. Screenshot automático em erro: {SETTINGS['screenshot_on_error']}")
        print("11. Voltar")

        raw = input("\nEscolha o item para editar: ").strip()
        if raw == "1":
            idx = ask_choice("Navegador:", ["chrome", "firefox", "edge"])
            if idx is not None:
                b["type"] = ["chrome", "firefox", "edge"][idx]
        elif raw == "2":
            b["headless"] = ask_yes_no(
                "Rodar sem janela visível (recomendado para não atrapalhar seu uso do PC)?",
                default=True,
            )
        elif raw == "3":
            w = ask_text("Largura", default=str(b["window_size"][0]))
            h = ask_text("Altura", default=str(b["window_size"][1]))
            b["window_size"] = [int(w), int(h)]
        elif raw == "4":
            path = ask_text(
                "Caminho absoluto do profile (deixe vazio para nenhum)", allow_empty=True
            )
            b["profile_path"] = path or None
        elif raw == "5":
            b["implicit_wait"] = ask_float("Espera implícita (segundos)", b["implicit_wait"])
        elif raw == "6":
            SETTINGS["data_folder"] = ask_text("Pasta de dados", default=SETTINGS["data_folder"])
        elif raw == "7":
            SETTINGS["log_folder"] = ask_text("Pasta de logs", default=SETTINGS["log_folder"])
        elif raw == "8":
            SETTINGS["reports_folder"] = ask_text(
                "Pasta de relatórios", default=SETTINGS["reports_folder"]
            )
        elif raw == "9":
            SETTINGS["default_retries"] = int(
                ask_float("Tentativas extras em falha transitória", SETTINGS["default_retries"])
            )
        elif raw == "10":
            SETTINGS["screenshot_on_error"] = ask_yes_no(
                "Tirar screenshot automático quando um passo falhar definitivamente?",
                default=SETTINGS["screenshot_on_error"],
            )
        elif raw == "11":
            cfg.save_settings(SETTINGS)
            return
        else:
            print("Opção inválida.")
        cfg.save_settings(SETTINGS)


# ---------------------------------------------------------------------------
# Menu principal
# ---------------------------------------------------------------------------
def main():
    while True:
        clear()
        ativos = list(RUNNING_THREADS.keys())
        print("=" * 55)
        print("     AUTOMAÇÃO WEB - MENU PRINCIPAL (White Label)")
        print("=" * 55)
        if ativos:
            print(f"  Execuções ativas em segundo plano: {', '.join(ativos)}")
        print()
        print("  1. Executar Macro")
        print("  2. Marcar Coordenadas (criar/editar/reordenar macro)")
        print("  3. Limpar Coordenadas")
        print("  4. Gerenciar Macros (duplicar/exportar/importar/renomear)")
        print("  5. Configurações")
        print("  6. Sair")

        raw = input("\nEscolha uma opção: ").strip()
        if raw == "1":
            menu_executar_macro()
        elif raw == "2":
            menu_marcar_coordenadas()
        elif raw == "3":
            menu_limpar_coordenadas()
        elif raw == "4":
            menu_gerenciar_macros()
        elif raw == "5":
            menu_configuracoes()
        elif raw == "6":
            if RUNNING_THREADS:
                print("Há execuções em segundo plano. Elas serão interrompidas ao sair.")
                if not ask_yes_no("Confirma saída?", default=False):
                    continue
            print("Até logo!")
            sys.exit(0)
        else:
            print("Opção inválida.")
            time.sleep(1)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nInterrompido pelo operador.")
        sys.exit(0)
