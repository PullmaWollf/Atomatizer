"""
test_config_manager.py
Valida o CRUD completo de macros: criar, listar, duplicar, renomear,
exportar para fora do projeto, importar de fora do projeto e excluir.
Roda em uma pasta temporária isolada (não mexe nos macros reais do usuário).
"""
import os
import sys
import json
import shutil
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core import config_manager as cfg


class TestConfigManager(unittest.TestCase):
    def setUp(self):
        self.tmp_dir = tempfile.mkdtemp()
        self._orig_macros_dir = cfg.MACROS_DIR
        cfg.MACROS_DIR = os.path.join(self.tmp_dir, "macros")

    def tearDown(self):
        cfg.MACROS_DIR = self._orig_macros_dir
        shutil.rmtree(self.tmp_dir, ignore_errors=True)

    def _macro_dict(self, name):
        return {"name": name, "start_url": "https://exemplo.com", "steps": []}

    def test_save_and_load_macro(self):
        cfg.save_macro("teste1", self._macro_dict("teste1"))
        loaded = cfg.load_macro("teste1")
        self.assertEqual(loaded["name"], "teste1")

    def test_list_macros(self):
        cfg.save_macro("a", self._macro_dict("a"))
        cfg.save_macro("b", self._macro_dict("b"))
        self.assertEqual(cfg.list_macros(), ["a", "b"])

    def test_load_nonexistent_macro_raises(self):
        with self.assertRaises(FileNotFoundError):
            cfg.load_macro("nao_existe")

    def test_delete_macro(self):
        cfg.save_macro("apagar", self._macro_dict("apagar"))
        cfg.delete_macro("apagar")
        self.assertNotIn("apagar", cfg.list_macros())

    def test_duplicate_macro(self):
        cfg.save_macro("original", self._macro_dict("original"))
        cfg.duplicate_macro("original", "copia")
        self.assertIn("copia", cfg.list_macros())
        self.assertIn("original", cfg.list_macros())
        self.assertEqual(cfg.load_macro("copia")["name"], "copia")

    def test_duplicate_macro_existing_name_raises(self):
        cfg.save_macro("m1", self._macro_dict("m1"))
        cfg.save_macro("m2", self._macro_dict("m2"))
        with self.assertRaises(FileExistsError):
            cfg.duplicate_macro("m1", "m2")

    def test_rename_macro(self):
        cfg.save_macro("nome_antigo", self._macro_dict("nome_antigo"))
        cfg.rename_macro("nome_antigo", "nome_novo")
        self.assertNotIn("nome_antigo", cfg.list_macros())
        self.assertIn("nome_novo", cfg.list_macros())

    def test_export_and_import_macro_roundtrip(self):
        cfg.save_macro("exportavel", self._macro_dict("exportavel"))
        destino = os.path.join(self.tmp_dir, "backup", "exportavel.json")
        path = cfg.export_macro("exportavel", destino)
        self.assertTrue(os.path.exists(path))

        cfg.delete_macro("exportavel")
        self.assertNotIn("exportavel", cfg.list_macros())

        nome_importado = cfg.import_macro(path)
        self.assertEqual(nome_importado, "exportavel")
        self.assertIn("exportavel", cfg.list_macros())

    def test_import_with_new_name(self):
        cfg.save_macro("original2", self._macro_dict("original2"))
        destino = os.path.join(self.tmp_dir, "original2.json")
        cfg.export_macro("original2", destino)
        nome = cfg.import_macro(destino, new_name="renomeado_na_importacao")
        self.assertEqual(nome, "renomeado_na_importacao")
        self.assertEqual(
            cfg.load_macro("renomeado_na_importacao")["name"], "renomeado_na_importacao"
        )

    def test_import_nonexistent_file_raises(self):
        with self.assertRaises(FileNotFoundError):
            cfg.import_macro(os.path.join(self.tmp_dir, "nao_existe.json"))


if __name__ == "__main__":
    unittest.main(verbosity=2)
