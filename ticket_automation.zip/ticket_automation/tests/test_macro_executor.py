"""
test_macro_executor.py

Valida TODA a lógica do MacroExecutor sem precisar de um navegador real:
usa unittest.mock para simular o WebDriver e os elementos HTML. Isso
garante que a lógica de cada ação, a resolução de valores (fixo / dados /
variável capturada), o retry automático, o modo opcional e o screenshot
em erro estão corretos antes de qualquer teste manual no navegador.
"""
import os
import sys
import shutil
import tempfile
import unittest
from unittest.mock import MagicMock, patch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from selenium.common.exceptions import (
    NoSuchElementException,
    StaleElementReferenceException,
    TimeoutException,
)

from core.macro import Macro, MacroStep, MacroExecutor


def make_step(**kwargs):
    defaults = dict(id=1, action="click", locator_type="ID", locator_value="alvo", timeout=0.3)
    defaults.update(kwargs)
    return MacroStep(**defaults)


def make_driver():
    """Cria um driver mockado cujo elemento padrão se comporta como um
    elemento HTML real e visível (is_displayed/is_enabled=True), que é o
    que o Selenium exige internamente para as condições 'clicável' e
    'visível' usadas por click/type/select/extract/hover/etc."""
    driver = MagicMock()
    driver.find_element.return_value.is_displayed.return_value = True
    driver.find_element.return_value.is_enabled.return_value = True
    return driver


class TestValueResolution(unittest.TestCase):
    def setUp(self):
        self.driver = make_driver()
        self.executor = MacroExecutor(self.driver, default_retries=0, screenshot_on_error=False)

    def test_fixed_value(self):
        step = make_step(value_source="fixed", value="Ola mundo")
        self.assertEqual(self.executor._resolve_value(step, None), "Ola mundo")

    def test_data_value(self):
        step = make_step(value_source="data", value="cliente")
        self.assertEqual(
            self.executor._resolve_value(step, {"cliente": "Miss Make 12"}), "Miss Make 12"
        )

    def test_data_value_missing_row_raises(self):
        step = make_step(value_source="data", value="cliente")
        with self.assertRaises(ValueError):
            self.executor._resolve_value(step, None)

    def test_data_value_missing_column_raises(self):
        step = make_step(value_source="data", value="inexistente")
        with self.assertRaises(KeyError):
            self.executor._resolve_value(step, {"cliente": "x"})

    def test_data_row_empty_dict_raises_keyerror_not_valueerror(self):
        """Regressão: uma linha de dados vazia ({}) é uma linha REAL (só sem
        a coluna pedida) e deve gerar KeyError sobre a coluna, não ValueError
        de 'nenhuma linha fornecida' (esse é o caso de data_row=None)."""
        step = make_step(value_source="data", value="cliente")
        with self.assertRaises(KeyError):
            self.executor._resolve_value(step, {})

    def test_captured_value(self):
        self.executor.variables["ticket_id"] = "TCK-999"
        step = make_step(value_source="captured", value="ticket_id")
        self.assertEqual(self.executor._resolve_value(step, None), "TCK-999")

    def test_captured_value_missing_raises(self):
        step = make_step(value_source="captured", value="nao_existe")
        with self.assertRaises(KeyError):
            self.executor._resolve_value(step, None)

    def test_template_substitution_in_fixed_value(self):
        self.executor.variables["ticket_id"] = "TCK-42"
        step = make_step(value_source="fixed", value="Confirmação: {{ticket_id}}")
        self.assertEqual(self.executor._resolve_value(step, None), "Confirmação: TCK-42")

    def test_template_substitution_keeps_unknown_placeholder(self):
        step = make_step(value_source="fixed", value="valor {{desconhecido}}")
        self.assertEqual(self.executor._resolve_value(step, None), "valor {{desconhecido}}")


class TestBasicActions(unittest.TestCase):
    def setUp(self):
        self.driver = make_driver()
        self.executor = MacroExecutor(self.driver, default_retries=0, screenshot_on_error=False)

    def test_click(self):
        step = make_step(action="click")
        self.executor._execute(step, None)
        self.driver.find_element.assert_called()

    def test_type_clears_then_sends_keys(self):
        el = self.driver.find_element.return_value
        step = make_step(action="type", value_source="fixed", value="teste123")
        self.executor._execute(step, None)
        el.clear.assert_called_once()
        el.send_keys.assert_called_once_with("teste123")

    def test_clear_action(self):
        el = self.driver.find_element.return_value
        step = make_step(action="clear")
        self.executor._execute(step, None)
        el.clear.assert_called_once()

    def test_scroll_to_executes_js_with_element(self):
        el = self.driver.find_element.return_value
        step = make_step(action="scroll_to")
        self.executor._execute(step, None)
        self.driver.execute_script.assert_called_once()
        args = self.driver.execute_script.call_args[0]
        self.assertIn("scrollIntoView", args[0])
        self.assertIs(args[1], el)

    def test_wait_sleeps_configured_seconds(self):
        step = make_step(action="wait", locator_type=None, locator_value=None, value="0")
        # não deve levantar exceção e não deve chamar find_element
        self.executor._execute(step, None)
        self.driver.find_element.assert_not_called()

    def test_upload_file_resolves_path_via_data_source(self):
        el = self.driver.find_element.return_value
        data_source = MagicMock()
        data_source.resolve_path.return_value = "/abs/path/anexo.png"
        executor = MacroExecutor(self.driver, data_source=data_source, default_retries=0)
        step = make_step(action="upload_file", value_source="fixed", value="anexo.png")
        executor._execute(step, None)
        data_source.resolve_path.assert_called_once_with("anexo.png")
        el.send_keys.assert_called_once_with("/abs/path/anexo.png")


class TestMouseAndKeyboard(unittest.TestCase):
    def setUp(self):
        self.driver = make_driver()
        self.executor = MacroExecutor(self.driver, default_retries=0, screenshot_on_error=False)

    @patch("core.macro.ActionChains")
    def test_double_click(self, mock_chains):
        step = make_step(action="double_click")
        self.executor._execute(step, None)
        mock_chains.return_value.double_click.assert_called_once()
        mock_chains.return_value.double_click.return_value.perform.assert_called_once()

    @patch("core.macro.ActionChains")
    def test_right_click(self, mock_chains):
        step = make_step(action="right_click")
        self.executor._execute(step, None)
        mock_chains.return_value.context_click.assert_called_once()

    @patch("core.macro.ActionChains")
    def test_hover(self, mock_chains):
        step = make_step(action="hover")
        self.executor._execute(step, None)
        mock_chains.return_value.move_to_element.assert_called_once()

    def test_press_key_with_locator(self):
        el = self.driver.find_element.return_value
        step = make_step(action="press_key", value="ENTER")
        self.executor._execute(step, None)
        el.send_keys.assert_called_once()

    def test_press_key_without_locator_uses_active_element(self):
        step = make_step(action="press_key", locator_type=None, locator_value=None, value="TAB")
        self.executor._execute(step, None)
        self.driver.switch_to.active_element.send_keys.assert_called_once()

    def test_press_key_invalid_name_raises(self):
        step = make_step(action="press_key", value="TECLA_INEXISTENTE")
        with self.assertRaises(ValueError):
            self.executor._execute(step, None)


class TestSelectDropdown(unittest.TestCase):
    def setUp(self):
        self.driver = make_driver()
        self.executor = MacroExecutor(self.driver, default_retries=0, screenshot_on_error=False)

    @patch("core.macro.Select")
    def test_select_by_text(self, mock_select_cls):
        step = make_step(action="select", value_source="fixed", value="Opção A", select_by="text")
        self.executor._execute(step, None)
        mock_select_cls.return_value.select_by_visible_text.assert_called_once_with("Opção A")

    @patch("core.macro.Select")
    def test_select_by_value(self, mock_select_cls):
        step = make_step(action="select", value_source="fixed", value="opt_a", select_by="value")
        self.executor._execute(step, None)
        mock_select_cls.return_value.select_by_value.assert_called_once_with("opt_a")

    @patch("core.macro.Select")
    def test_select_by_index(self, mock_select_cls):
        step = make_step(action="select", value_source="fixed", value="2", select_by="index")
        self.executor._execute(step, None)
        mock_select_cls.return_value.select_by_index.assert_called_once_with(2)


class TestExtractAndJs(unittest.TestCase):
    def setUp(self):
        self.driver = make_driver()
        self.executor = MacroExecutor(self.driver, default_retries=0, screenshot_on_error=False)

    def test_extract_text(self):
        el = self.driver.find_element.return_value
        el.text = "Ticket #4821 criado"
        step = make_step(action="extract", value=None, variable_name="msg")
        self.executor._execute(step, None)
        self.assertEqual(self.executor.variables["msg"], "Ticket #4821 criado")

    def test_extract_attribute(self):
        el = self.driver.find_element.return_value
        el.get_attribute.return_value = "4821"
        step = make_step(action="extract", value="data-id", variable_name="ticket_id")
        self.executor._execute(step, None)
        el.get_attribute.assert_called_once_with("data-id")
        self.assertEqual(self.executor.variables["ticket_id"], "4821")

    def test_extract_without_variable_name_raises(self):
        step = make_step(action="extract", value=None, variable_name=None)
        with self.assertRaises(ValueError):
            self.executor._execute(step, None)

    def test_execute_js_captures_return_value(self):
        self.driver.execute_script.return_value = 42
        step = make_step(
            action="execute_js",
            locator_type=None,
            locator_value=None,
            value="return document.title.length;",
            variable_name="tamanho",
        )
        self.executor._execute(step, None)
        self.assertEqual(self.executor.variables["tamanho"], 42)


class TestScreenshotFramesWindowsAlerts(unittest.TestCase):
    def setUp(self):
        self.driver = make_driver()
        self.executor = MacroExecutor(
            self.driver, default_retries=0, screenshot_on_error=False,
            screenshot_dir=tempfile.mkdtemp(),
        )

    def test_screenshot_manual(self):
        step = make_step(
            action="screenshot", locator_type=None, locator_value=None, value="print1.png"
        )
        self.executor._execute(step, None)
        self.driver.save_screenshot.assert_called_once()
        path_arg = self.driver.save_screenshot.call_args[0][0]
        self.assertTrue(path_arg.endswith("print1.png"))

    def test_switch_to_frame(self):
        el = self.driver.find_element.return_value
        step = make_step(action="switch_to_frame")
        self.executor._execute(step, None)
        self.driver.switch_to.frame.assert_called_once_with(el)

    def test_switch_to_default_content(self):
        step = make_step(action="switch_to_default_content", locator_type=None, locator_value=None)
        self.executor._execute(step, None)
        self.driver.switch_to.default_content.assert_called_once()

    def test_switch_to_window_valid_index(self):
        self.driver.window_handles = ["h0", "h1", "h2"]
        step = make_step(action="switch_to_window", locator_type=None, locator_value=None, value="1")
        self.executor._execute(step, None)
        self.driver.switch_to.window.assert_called_once_with("h1")

    def test_switch_to_window_invalid_index_raises(self):
        self.driver.window_handles = ["h0"]
        step = make_step(action="switch_to_window", locator_type=None, locator_value=None, value="5")
        with self.assertRaises(NoSuchElementException):
            self.executor._execute(step, None)

    def test_accept_alert(self):
        step = make_step(action="accept_alert", locator_type=None, locator_value=None)
        self.executor._execute(step, None)
        self.driver.switch_to.alert.accept.assert_called_once()

    def test_dismiss_alert(self):
        step = make_step(action="dismiss_alert", locator_type=None, locator_value=None)
        self.executor._execute(step, None)
        self.driver.switch_to.alert.dismiss.assert_called_once()

    def test_type_in_alert(self):
        step = make_step(
            action="type_in_alert", locator_type=None, locator_value=None,
            value_source="fixed", value="1234",
        )
        self.executor._execute(step, None)
        self.driver.switch_to.alert.send_keys.assert_called_once_with("1234")


class TestRetryLogic(unittest.TestCase):
    def test_retries_then_succeeds_on_transient_error(self):
        driver = make_driver()
        good_element = driver.find_element.return_value
        driver.find_element.side_effect = [
            StaleElementReferenceException("stale"),
            good_element,
        ]
        executor = MacroExecutor(driver, default_retries=1, screenshot_on_error=False)
        macro = Macro(name="m", steps=[])
        step = make_step(action="click", timeout=0.2)
        # não deve levantar exceção: a 2a tentativa deve funcionar
        executor._run_step_with_retry(macro, step, None)
        self.assertEqual(driver.find_element.call_count, 2)

    def test_gives_up_after_max_attempts_and_raises(self):
        driver = MagicMock()
        driver.find_element.side_effect = NoSuchElementException("nunca encontrado")
        executor = MacroExecutor(driver, default_retries=1, screenshot_on_error=False)
        macro = Macro(name="m", steps=[])
        step = make_step(action="click", timeout=0.15)
        with self.assertRaises(TimeoutException):
            executor._run_step_with_retry(macro, step, None)

    def test_optional_step_does_not_raise_after_failure(self):
        driver = MagicMock()
        driver.find_element.side_effect = NoSuchElementException("nunca encontrado")
        executor = MacroExecutor(driver, default_retries=0, screenshot_on_error=False)
        macro = Macro(name="m", steps=[])
        step = make_step(action="click", timeout=0.15, optional=True)
        # não deve levantar exceção mesmo falhando
        executor._run_step_with_retry(macro, step, None)

    def test_screenshot_saved_on_definitive_failure(self):
        driver = MagicMock()
        driver.find_element.side_effect = NoSuchElementException("nunca encontrado")
        tmp_dir = tempfile.mkdtemp()
        executor = MacroExecutor(
            driver, default_retries=0, screenshot_on_error=True, screenshot_dir=tmp_dir
        )
        macro = Macro(name="macro_teste", steps=[])
        step = make_step(action="click", timeout=0.15)
        with self.assertRaises(TimeoutException):
            executor._run_step_with_retry(macro, step, None)
        driver.save_screenshot.assert_called_once()
        shutil.rmtree(tmp_dir, ignore_errors=True)


class TestFullRunWithDataRows(unittest.TestCase):
    def test_run_resets_variables_and_returns_captured(self):
        driver = make_driver()
        el = driver.find_element.return_value
        el.get_attribute.return_value = "TCK-1"
        driver.execute_script.return_value = None

        macro = Macro(name="fluxo", start_url="https://exemplo.com")
        macro.steps = [
            MacroStep(id=1, action="type", locator_type="ID", locator_value="titulo",
                      value_source="data", value="titulo"),
            MacroStep(id=2, action="click", locator_type="ID", locator_value="salvar"),
            MacroStep(id=3, action="extract", locator_type="ID", locator_value="numero_ticket",
                      value="data-id", variable_name="ticket_id"),
        ]
        executor = MacroExecutor(driver, default_retries=0, screenshot_on_error=False)
        variaveis = executor.run(macro, data_row={"titulo": "Erro de TEF"})

        driver.get.assert_called_once_with("https://exemplo.com")
        self.assertEqual(variaveis["ticket_id"], "TCK-1")
        self.assertEqual(executor.variables["ticket_id"], "TCK-1")

        # rodar de novo (ex: próxima linha do CSV) deve zerar variáveis antigas
        el.get_attribute.return_value = "OUTRO"
        variaveis2 = executor.run(macro, data_row={"titulo": "Outro chamado"})
        self.assertEqual(variaveis2["ticket_id"], "OUTRO")


if __name__ == "__main__":
    unittest.main(verbosity=2)
